from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name="home"),
    path('login',views.login,name="login"),
    path('page2',views.page2,name="page2"),
    path('page3',views.page3,name="page3"),
    path('register',views.register,name="register"),
    path('Choice',views.Choice,name="choice"),
    path('load_image', views.load_image,name="load_image"),
    path('load_image1',views.load_image1,name="load_image1"),
    path('authenticate',views.authenticate,name="authenticate"),
    path('welcome',views.welcome,name="welcome"),
    path('load_again',views.load_again,name="load_again"),
]