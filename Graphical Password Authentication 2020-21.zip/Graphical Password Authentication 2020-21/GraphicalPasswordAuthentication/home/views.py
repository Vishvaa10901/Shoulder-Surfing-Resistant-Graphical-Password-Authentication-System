from django.shortcuts import render,redirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.models import User,auth
from .models import Register,choice
from . import image_render
import os
from django.conf import settings
import numpy as np

# Create your views here.
def home(request):
    return render(request,"index.html")

def login(request):
    return render(request,"login.html")

def page2(request):
    return render(request,"page2.html")

def page3(request):
    return render(request,"page3.html")

def register(request):
    Username = request.POST['Username']
    Email = request.POST['email']
    PhoneNo = request.POST['phone']

    if Register.objects.filter(Username=Username).exists():
        messages.info(request,'Usrname already taken')
        return redirect('home')
    elif Register.objects.filter(Email=Email).exists():
        messages.info(request,'Email already taken')
        return redirect('home')
    elif Register.objects.filter(PhoneNo=PhoneNo).exists():
        messages.info(request,'Phone Number already taken')
        return redirect('home')
    else:
        register = Register(Username=Username,Email=Email,PhoneNo=PhoneNo)
        register.save()
        request.session['userid']=Username
    return redirect('page2')

def load_image1(request):
    return render(request, 'load_image.html')

def load_again(request):
    uid = request.session['userid']
    if choice.objects.filter(user=uid).exists():
        ch = choice.objects.values()
        for cho in ch:
            if cho['user'] == uid:
                image_render.my_fun(cho)
                return redirect('load_image1')
    messages.info(request,'Invalid Username')
    return redirect('login')

def load_image(request):
    uid = request.POST['uid']
    request.session['userid']=uid
    if choice.objects.filter(user=uid).exists():
        ch = choice.objects.values()
        for cho in ch:
            if cho['user'] == uid:
                image_render.my_fun(cho)
                return redirect('load_image1')
    messages.info(request,'Invalid Username')
    return redirect('login')
    # image_render.my_fun(uid)
    # return redirect('load_image1')

def Choice(request):
    user=request.session['userid']
    choices = request.POST['attendance']
    ch = choice(user=user,choices=choices)
    ch.save()
    messages.info(request,'Success')
    return redirect('page3')

def welcome(request):
    return render(request, 'welcome.html')

def authenticate(request):
    string = request.POST['selection']
    print(string)
    selected = []
    j=4
    while(j < len(string)):
        selected.append(string[j])
        j=j+10
    selected = list(map(int, selected))
    print("selected: ", selected)
    if(len(selected) < 6):
        messages.info(request, 'Invalid number of selection')
        return render(request, 'load_image.html')

    file_path = os.path.join(settings.MEDIA_ROOT,'labelChoices.txt')
    # print("file path = ", file_path)
    labelFile = open(file_path, 'r')
    string = labelFile.read()
    string = string[1:-1]
    labelChoices = list(map(int, string.split(',')))
    print("labelChoices: ", labelChoices)

    file_path = os.path.join(settings.MEDIA_ROOT,'inputLabels.txt')
    # print("file path = ", file_path)
    inputFile = open(file_path, 'r')
    string = inputFile.read()
    string = string[1:-1]
    inputLabels = list(map(int, string.split(',')))
    print("inputLabels: ", inputLabels)

    flag = 1
    for i in range(len(selected)):
        selected[i] = inputLabels[selected[i]]
        if(selected[i] in labelChoices):
            flag = 1
            break
        else:
            flag = 0
    if flag == 0:
        print("selected: ", selected)
        messages.info(request, 'Success')
        return redirect('welcome')
    else:
        messages.info(request, 'Invalid choices, Enter Again')
    return redirect('load_again')
